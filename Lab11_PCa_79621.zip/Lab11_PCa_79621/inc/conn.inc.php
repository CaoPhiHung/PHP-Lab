<?php

$connection = new mysqli("localhost", "root", "", "books") or die(mysqli_error());

?>
