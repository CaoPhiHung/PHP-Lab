<?php

//Define our constants for configuration
define('DBUSER', "root");
define('DBPASSWD', "");

?>