<?php 
 define("DBSERVER","localhost"); 
 define("DB","Lab10"); 
 define("DBUSER","root"); 
 define("DBPASSWD",""); 
?>